<?php
/**
 * Magento Enterprise Edition
 *
 * NOTICE OF LICENSE
 *
 * This source file is subject to the Magento Enterprise Edition License
 * that is bundled with this package in the file LICENSE_EE.txt.
 * It is also available through the world-wide-web at this URL:
 * http://www.magentocommerce.com/license/enterprise-edition
 * If you did not receive a copy of the license and are unable to
 * obtain it through the world-wide-web, please send an email
 * to license@magentocommerce.com so we can send you a copy immediately.
 *
 * DISCLAIMER
 *
 * Do not edit or add to this file if you wish to upgrade Magento to newer
 * versions in the future. If you wish to customize Magento for your
 * needs please refer to http://www.magentocommerce.com for more information.
 *
 * @category    Mage
 * @package     Mage_Tax
 * @copyright   Copyright (c) 2012 Magento Inc. (http://www.magentocommerce.com)
 * @license     http://www.magentocommerce.com/license/enterprise-edition
 */

/**
 * Tax totals modification block. Can be used just as subblock of Mage_Sales_Block_Order_Totals
 */
class Silk_CybersourceTax_Block_Sales_Order_Tax extends Mage_Tax_Block_Sales_Order_Tax
{
    

    /**
     * Initialize all order totals relates with tax
     *
     * @return Mage_Tax_Block_Sales_Order_Tax
     */
    public function initTotals()
    {
        /** @var $parent Mage_Adminhtml_Block_Sales_Order_Invoice_Totals */
        $parent = $this->getParentBlock();
        $this->_order   = $parent->getOrder();
        $this->_source  = $parent->getSource();
        
        //$this->_initBreakdownTax('city_tax', 'City Tax', $this->_source->getCityTax());
        //$this->_initBreakdownTax('county_tax', 'County Tax', $this->_source->getCountyTax());
        //$this->_initBreakdownTax('district_tax', 'District Tax', $this->_source->getDistrictTax());
       // $this->_initBreakdownTax('state_tax', 'State Tax', $this->_source->getStateTax());

        $store = $this->getStore();
        $allowTax = ($this->_source->getTaxAmount() > 0) || ($this->_config->displaySalesZeroTax($store));
        $grandTotal = (float) $this->_source->getGrandTotal();
        if (!$grandTotal || ($allowTax && !$this->_config->displaySalesTaxWithGrandTotal($store))) {
            $this->_addTax();
        }
        
        $this->_initSubtotal();
        $this->_initShipping();
        $this->_initDiscount();
        $this->_initGrandTotal();
        return $this;
    }


 protected function _initBreakdownTax($code, $title, $val)
    {
        if ($val>0) {   
            $taxTotal = new Varien_Object(array(
                'code'      => $code,
                'value'     => $val,
                'label'=> $title
            ));
            $this->getParentBlock()->addTotal($taxTotal);
        } 
        return $this;
    }
    
    
    
    public function getFullTaxInfo()
    {
       $fullInfo = array();
        
        $summary = array();
        if ($this->_order->getStateTax() > 0)
            $summary[] = array('name'=>'State Tax', 'rate'=>number_format($this->_order->getStateTax()/$this->_order->getSubtotal(), 4) * 100, 'amt'=>$this->_order->getStateTax());
        
        if ($this->_order->getCityTax() > 0)
            $summary[] = array('name'=>'City Tax', 'rate'=>number_format($this->_order->getCityTax()/$this->_order->getSubtotal(), 4) * 100, 'amt'=>$this->_order->getCityTax());
       
        if ($this->_order->getCountyTax() > 0)
            $summary[] = array('name'=>'County Tax', 'rate'=>number_format($this->_order->getCountyTax()/$this->_order->getSubtotal(), 4) * 100, 'amt'=>$this->_order->getCountyTax());
        
        if ($this->_order->getDistrictTax() > 0)
            $summary[] = array('name'=>'District Tax', 'rate'=>number_format($this->_order->getDistrictTax()/$this->_order->getSubtotal(), 4) * 100, 'amt'=>$this->_order->getDistrictTax());
        
        foreach ($summary as $key => $row) {
            $id = 'cyber-' . $key;
            $fullInfo[$id] = array(
                'rates' => array(array(
                        'code' => $row['name'],
                        'title' => $row['name'],
                        'percent' => $row['rate'],
                        'position' => $key,
                        'priority' => $key,
                        'rule_id' => 0
                )),
                'percent' => $row['rate'],
                'id' => $id,
                'process' => 0,
                'amount' => $row['amt'],
                'base_amount' => $row['amt']
            );
        }

        return $fullInfo;
     }
    
    
    
}
