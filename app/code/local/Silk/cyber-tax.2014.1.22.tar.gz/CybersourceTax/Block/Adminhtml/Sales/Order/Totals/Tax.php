<?php
/**
 * Magento Enterprise Edition
 *
 * NOTICE OF LICENSE
 *
 * This source file is subject to the Magento Enterprise Edition License
 * that is bundled with this package in the file LICENSE_EE.txt.
 * It is also available through the world-wide-web at this URL:
 * http://www.magentocommerce.com/license/enterprise-edition
 * If you did not receive a copy of the license and are unable to
 * obtain it through the world-wide-web, please send an email
 * to license@magentocommerce.com so we can send you a copy immediately.
 *
 * DISCLAIMER
 *
 * Do not edit or add to this file if you wish to upgrade Magento to newer
 * versions in the future. If you wish to customize Magento for your
 * needs please refer to http://www.magentocommerce.com for more information.
 *
 * @category    Mage
 * @package     Mage_Adminhtml
 * @copyright   Copyright (c) 2012 Magento Inc. (http://www.magentocommerce.com)
 * @license     http://www.magentocommerce.com/license/enterprise-edition
 */

/**
 * Adminhtml order tax totals block
 *
 * @category    Mage
 * @package     Mage_Adminhtml
 * @author      Magento Core Team <core@magentocommerce.com>
 */
class Silk_CybersourceTax_Block_Adminhtml_Sales_Order_Totals_Tax extends Silk_CybersourceTax_Block_Sales_Order_Tax
{
    /**
     * Get full information about taxes applied to order
     *
     * @return array
     */
    public function getFullTaxInfo()
    {
        /** @var $source Mage_Sales_Model_Order */
        $source = $this->getOrder();

        $fullInfo = array();
        
        $summary = array();
        $finalTotal = $source->getSubtotal()+$source->getDiscountAmount();
        if ($source->getStateTax() > 0)
            $summary[] = array('name'=>'State Tax', 'rate'=>number_format($source->getStateTax()/$finalTotal, 4) * 100, 'amt'=>$source->getStateTax());
        
        if ($source->getCityTax() > 0)
            $summary[] = array('name'=>'City Tax', 'rate'=>number_format($source->getCityTax()/$finalTotal, 4) * 100, 'amt'=>$source->getCityTax());
       
        if ($source->getCountyTax() > 0)
            $summary[] = array('name'=>'County Tax', 'rate'=>number_format($source->getCountyTax()/$finalTotal, 4) * 100, 'amt'=>$source->getCountyTax());
        
        if ($source->getDistrictTax() > 0)
            $summary[] = array('name'=>'District Tax', 'rate'=>number_format($source->getDistrictTax()/$finalTotal, 4) * 100, 'amt'=>$source->getDistrictTax());
        
        foreach ($summary as $key => $row) {
            $id = 'cyber-' . $key;
            $fullInfo[$id] = array(
                'rates' => array(array(
                        'code' => $row['name'],
                        'title' => $row['name'],
                        'percent' => $row['rate'],
                        'position' => $key,
                        'priority' => $key,
                        'rule_id' => 0
                )),
                'percent' => $row['rate'],
                'id' => $id,
                'process' => 0,
                'title' => $row['name'],
                'tax_amount' => $row['amt'],
                'base_tax_amount' => $row['amt']
            );
        }

        return $fullInfo;
    }

    /**
     * Display tax amount
     *
     * @return string
     */
    public function displayAmount($amount, $baseAmount)
    {
        return Mage::helper('adminhtml/sales')->displayPrices(
            $this->getSource(), $baseAmount, $amount, false, '<br />'
        );
    }

    /**
     * Get store object for process configuration settings
     *
     * @return Mage_Core_Model_Store
     */
    public function getStore()
    {
        return Mage::app()->getStore();
    }
}
